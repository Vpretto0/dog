# perro_pistolero_0010 > 2025-04-26 3:46pm
https://universe.roboflow.com/perropistolero/perro_pistolero_0010

Provided by a Roboflow user
License: CC BY 4.0

